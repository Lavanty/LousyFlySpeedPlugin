package me.lousy.home.lousyflyspeed;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

class FlySpeedPlugin extends JavaPlugin {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("flyspeed") && sender instanceof Player) {
            Player player = (Player) sender;

            if (args.length == 1) {
                try {
                    float speed = Float.parseFloat(args[0]);
                    if (speed >= 0.1f && speed <= 10.0f) { // Set a reasonable range
                        player.setFlySpeed(speed);
                        player.sendMessage("Fly speed set to " + speed + "x.");
                    } else {
                        player.sendMessage("Invalid fly speed value. Please use a value between 0.1 and 10.0.");
                    }
                } catch (NumberFormatException e) {
                    player.sendMessage("Invalid number format. Please use a decimal value.");
                }
            } else {
                player.sendMessage("Usage: /flyspeed <speed>");
            }

            return true;
        }
        return false;
    }
}
